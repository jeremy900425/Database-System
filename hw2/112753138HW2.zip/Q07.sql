select Ssn, Dname
from Employee, Department