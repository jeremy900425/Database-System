select max(Salary),min(Salary),avg(Salary)
from Employee


