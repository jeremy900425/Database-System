select count(*) as num_employee
from Employee,Department
where Dno = Dnumber and Dname = "Research"


