select distinct Salary
from Employee