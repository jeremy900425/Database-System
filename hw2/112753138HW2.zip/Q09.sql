select *
from Employee
where Address like "%Houston TX%"