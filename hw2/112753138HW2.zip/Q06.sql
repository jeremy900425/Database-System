SELECT Ssn, Dno 
FROM Employee;
